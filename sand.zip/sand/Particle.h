#pragma once
#include <SDL.h>
#include "Material.h"

class Grid;

class Particle
{
public:
	Particle(Material* material, int x, int y, int size, float velocityX, float velocityY, Grid* grid); // cell size
	
	// width of cell
	~Particle();

	void update();
	void render(SDL_Renderer* renderer); // moeten wss die sdl renderer inpluggen
	//void fall(); // laat vallen later miss stijgen

	Material* getMaterial() const;
	int getX() const;
	int getY() const;

	void setX(int x);
	void setY(int y);

	int getSize() const;
	float getXVelocity() const;
	float getYVelocity() const;
	void setXVelocity(float x) ;
	void setYVelocity(float y) ;

private:
	int x, y, size;
	float velocityX, velocityY;

	Material* material;
	Grid* grid;
};

