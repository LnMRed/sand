#pragma once

#include <iostream>
#include <vector>
#include <utility>

#include "SDL.h"

#include "Grid.h"
#include "Particle.h"

enum class CurrentMaterial
{
	SAND,
	WATER
};


class Handler 
{
public:
	Handler();
	~Handler();

	void init(const char* title, int xpos, int ypos, int width, int height, bool fullScreen);

	void handleEvents();

	void update();
	void render();
	void clean();

	void createParticles(int x, int y);

	bool running();

	SDL_Renderer* getRenderer();

private:
	int	count = 0;
	bool isRunning;
	bool mouseDown;

	CurrentMaterial selectedMaterial = CurrentMaterial::SAND;

	SDL_Window* window;
	SDL_Renderer* renderer;

	Grid* grid;
	std::vector<Particle*> particles;
};