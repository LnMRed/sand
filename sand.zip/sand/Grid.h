#pragma once

#include "SDl.h"
#include <vector>
#include <cmath>

#include "Material.h"
#include "Particle.h"

class Grid 
{
public:
	Grid(int cols, int rows, int width); // width of cells
	~Grid();

	//std::vector<std::vector<int>> make2DArray(int cols, int rows);

	bool isOccupied(int x, int y) const;

	void updateGrid(const std::vector<Particle*>& particles); // idk of dit hier moet of dat dit in de handler moet?

	void swapParticles(int x, int y, int newX, int newY);

	Material* getMaterial(int x, int y);

	float checkCellDensity(int x, int y);

	int getCols();
	int getRows();
	int getWidth();

private:
	int cols;
	int rows;
	int width;
	std::vector<std::vector<int>> grid;
	std::vector<std::vector<Particle*>> cells;
};