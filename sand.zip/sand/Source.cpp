#include <SDL.h>
#include "Handler.h"

Handler *handler = nullptr;

// the pain engine aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa

int main(int argc, char* argv[])
{
	const int FPS = 100000;
	const int frameDelay = 1000 / FPS;

	Uint32 FrameStart;
	int FrameTime;

	handler = new Handler();
	handler->init("game", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 500 ,500, false);
	while (handler->running()) 
	{
		FrameStart = SDL_GetTicks64();

		handler->handleEvents();

		handler->update();

		SDL_SetRenderDrawColor(handler->getRenderer(), 255, 255, 255, 255);
		SDL_RenderClear(handler->getRenderer());

		handler->render();

		FrameTime = SDL_GetTicks64() - FrameStart;

		if (frameDelay > FrameTime) 
		{
			SDL_Delay(frameDelay - FrameTime);
		}
	}
	handler->clean();

	return 0;
}