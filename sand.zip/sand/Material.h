#pragma once
#include <SDL.h>

/*
	going to hold the materials and properties and whatever
	holds:

	density eg: how it interacts with gravity
	state eg: solid liquid gas
	color eg: color of material
	behaviour eg: how it interacts with other materials sticky or dissolving
*/
class Grid;
class Particle;

class Material
{
public:
	Material(float density, SDL_Color);
	// maybe later textures denk het niet tho vanwege pixels
	virtual~Material() {};

	virtual void update() = 0;
	virtual void interact(Particle* particle, Material* other, Grid* grid) = 0;
	virtual void render(SDL_Renderer* renderer, int x, int y, int size) = 0;

	virtual void fall(Particle* particle, Grid* grid) = 0;

	float getDensity() const;
	SDL_Color getColor() const;

protected:
	float density;
	SDL_Color color;
};

