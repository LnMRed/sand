#include "Material.h"

Material::Material(float density, SDL_Color) : density(density), color(color)
{

}


float Material::getDensity() const
{
	return density;
}

SDL_Color Material::getColor() const
{
	return color;
}


