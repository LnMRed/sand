#include "Handler.h"
#include <iostream>
#include "Sand.h"
#include "Water.h"

Handler::Handler() : isRunning(true), window(nullptr), renderer(nullptr), grid(new Grid(0, 0, 5))
{
}

Handler::~Handler()
{
    for (auto particle : particles)
    {
        delete particle;
    }
    delete grid;
}

void Handler::init(const char* title, int xpos, int ypos, int width, int height, bool fullScreen)
{
    int flags = 0;
    if (fullScreen)
    {
        flags = SDL_WINDOW_FULLSCREEN;
    }

    if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
    {
        std::cout << "subsystem initialized" << std::endl;
        window = SDL_CreateWindow(title, xpos, ypos, width, height, flags);
        if (window)
        {
            std::cout << "window made successfully" << std::endl;
        }
        renderer = SDL_CreateRenderer(window, -1, 0);
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
            SDL_RenderClear(renderer);
            SDL_RenderPresent(renderer);
            std::cout << "renderer initialized" << std::endl;
        }

        int cols = width ;
        int rows = height ;
        delete grid; // Delete the old grid
        grid = new Grid(cols, rows, 5);
    }
}

void Handler::handleEvents()
{
    int x, y;
    SDL_Event event;
    while (SDL_PollEvent(&event))
    {
        if (event.type == SDL_KEYDOWN) {
            switch (event.key.keysym.sym)
            {
            case SDLK_1:
                std::cout << "chosen material is sand " << std::endl;
                selectedMaterial = CurrentMaterial::SAND;
                break;
            case SDLK_2:
                std::cout << "chosen material is water " << std::endl;
                selectedMaterial = CurrentMaterial::WATER;
                break;
            default:
                break;
            }
        }
        switch (event.type)
        {
        case SDL_MOUSEBUTTONDOWN:
            x = event.button.x;
            y = event.button.y;
            createParticles(x, y);
            mouseDown = true;
            break;
        case SDL_MOUSEBUTTONUP:
            mouseDown = false;
            break;
        case SDL_MOUSEMOTION:
            if (mouseDown)
            {
                x = event.motion.x;
                y = event.motion.y;
                createParticles(x, y);
            }
            break;
        case SDL_QUIT:
            isRunning = false;
            break;
        }
    }
}

void Handler::update()
{
    for (auto particle : particles)
    {
        particle->update();
    }
    grid->updateGrid(particles);
}

void Handler::render()
{
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_RenderClear(renderer);

    for (auto particle : particles)
    {
        if (particle->getX() >= 0 && particle->getX() < grid->getCols() * grid->getWidth() && particle->getY() >= 0 && particle->getY() < grid->getRows() * grid->getWidth()) {
            particle->render(renderer);
        }
    }

    SDL_RenderPresent(renderer);
}

void Handler::clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
    std::cout << "game quit/cleaned" << std::endl;
}

void Handler::createParticles(int x, int y)
{
    Particle* newParticle = nullptr;

    switch (selectedMaterial)
    {
    case CurrentMaterial::SAND:
        newParticle = new Particle(new Sand(1, { 255, 0, 0, 255 }), x, y, 5, 0, 0, grid);
        break;
    case CurrentMaterial::WATER:
        newParticle = new Particle(new Water(0.5, { 0, 0, 255, 255 }), x, y, 5, 0, 0, grid);
        break;
    }

    if (newParticle) {
        particles.push_back(newParticle);
    }
}

SDL_Renderer* Handler::getRenderer()
{
    return renderer;
}

bool Handler::running()
{
    return isRunning;
}
