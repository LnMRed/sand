#include "Sand.h"
#include <SDL.h>

#include "Particle.h"
#include "Grid.h"
#include "Water.h"
#include <iostream>

Sand::Sand(float density, SDL_Color color) : Material(density, color)
{

}

void Sand::update()
{
	fall(particle, grid);
}

void Sand::interact(Particle* particle, Material* other, Grid* grid)
{
	if (dynamic_cast<Water*>(other) != nullptr)
	{
		int x = particle->getX() / grid->getWidth();
		int y = particle->getY() / grid->getWidth();
		int newY = y + 1;

		if (newY < grid->getRows())
		{
			grid->swapParticles(x, y, x, newY);
			particle->setY(newY * grid->getWidth());
		}
	}
}

void Sand::render(SDL_Renderer* renderer, int x, int y, int size)
{
	SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // kleur van de particle
	SDL_Rect rect = { x, y, size, size }; // sneller dan individuele pixels vgm
	SDL_RenderFillRect(renderer, &rect);
}

void Sand::fall(Particle* particle, Grid* grid)
{
	int x = particle->getX();
	int y = particle->getY();
	int size = particle->getSize();
	float velocityX = particle->getXVelocity();
	float velocityY = particle->getYVelocity();
	
	particle->setX(x + velocityX);
	particle->setY(y + velocityY);

	particle->setYVelocity(velocityY - 0.01f);

	int newX = x;
	int newY = y + 1; // check if cell is occupied

	bool moved = false;

	if (newY < grid->getRows() * grid->getWidth())
	{
		if (!grid->isOccupied(x, newY)) 
		{
			particle->setY(newY);
		}
		else
		{
			if (x > 0 && newY < grid->getRows() * grid->getWidth() && !grid->isOccupied(x - 1, newY))
			{
				particle->setX(newX - 1);
				particle->setY(newY);
				moved = true;
			}
			if (x < grid->getCols() - 1 && newY < grid->getRows() * grid->getWidth() && !grid->isOccupied(x + 1, newY))
			{
				particle->setX(newX - 1);
				particle->setY(newY);
				moved = true;
			}
		}
	}
	if (!moved)
	{
		particle->setYVelocity(1); //rook particles moeten -1 hebben
	}
	if (particle->getX() < 0) particle->setX(0);
	if (particle->getX() >= grid->getCols()) particle->setX(grid->getCols() - 1);
	if (particle->getY() < 0) particle->setY(0);
	if (particle->getY() >= grid->getRows()) particle->setY(grid->getRows() - 1);
	}
	
	
