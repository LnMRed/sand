#include "Grid.h"
#include <iostream>

Grid::Grid(int cols, int rows, int width) :cols(cols), rows(rows), width(width), cells(rows, std::vector<Particle*>(cols, nullptr)) 
{
	
}

Grid::~Grid()
{

}

bool Grid::isOccupied(int x, int y)const
{
	int gridX = x / width;
	int gridY = y / width;
	return gridX >= 0 && gridX < cols && gridY >= 0 && gridY < rows && cells[gridY][gridX] != nullptr;
}

void Grid::updateGrid(const std::vector<Particle*>& particles)
{
	for (auto& col : cells) 
	{
		std::fill(col.begin(), col.end(), nullptr);
	}

	for (auto particle : particles) 
	{
		int x = particle->getX() / width;
		int y = particle->getY() / width;

		particle->update();
		if (x >= 0 && x < cols && y >= 0 && y < rows) 
		{
			cells[y][x] = particle;
			// waarom valt het hierdoor niet als het y x is
		}
	}
}

void Grid::swapParticles(int x, int y, int newX, int newY)
{
	std::cout << x << " " << y << " " << newX << " " << newY << std::endl;
	if (x >= 0 && x < cols && y >= 0 && y < rows && newX >= 0 && newX < cols && newY >= 0 && newY < rows) {
		std::swap(cells[x][y], cells[newX][newY]);

		if (cells[y][x])
		{
			cells[y][x]->setX(x);
			cells[y][x]->setY(y);
		}
		if (cells[newY][newX])
		{
			cells[newY][newX]->setX(newX);
			cells[newY][newX]->setY(newY);
		}
	}
}

Material* Grid::getMaterial(int x, int y)
{
	// bounds check
	if (x >= 0 && x < cols && y >= 0 && y < rows) {
		Particle* particle = cells[y][x];
		return particle ? particle->getMaterial() : nullptr;
	}
	return nullptr;
}

float Grid::checkCellDensity(int x, int y) 
{
	int newY = y + 1;
	if (newY >= getRows()) {
		return -1;  // Indicate out of bounds
	}

	if (isOccupied(x, newY)) {
		Material* materialBelow = getMaterial(x, newY); // Assuming you have this method
		return materialBelow->getDensity();
	}
	else {
		return -1;  // Indicate that the cell is empty
	}
		
}

int Grid::getCols()
{
	return cols;
}

int Grid::getRows()
{
	return rows;
}

int Grid::getWidth()
{
	return width;
}
